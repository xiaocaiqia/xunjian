# 巡检脚本
## 说明
基于bash编写的巡检脚本，巡检目标是centos6或centos7服务器
